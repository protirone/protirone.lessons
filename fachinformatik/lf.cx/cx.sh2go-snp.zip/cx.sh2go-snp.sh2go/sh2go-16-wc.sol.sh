#!/bin/sh
#
# This file is part of the Open Source project 'proTirone'
# (c) 2025 Karsten Reincke (https://github.com/protirone/protico.ltx)
# It is distributed under the terms of the creative commons license
# CC-BY-4.0 (= https://creativecommons.org/licenses/by/4.0/)
#

# Lesehinweis: 
# In spitzen Klammern schreibe ich stets Tools und ihre Parameter.
# Die Tools stellt Ihnen Betriebssystem zur Verfügung.
#
# Beispiel: 
# Rufen Sie <echo dies> auf, meint, dass Sie an der
# Kommandozeile echo dies eingeben. Wo sich das Tool, hier
# <echo> bei Ihnen befindet, können Sie mit <which echo> erfragen

EXC=sh2go-16
echo "executing Uebung $EXC"

# Schreiben Sie ein Skript, dass die Datei, die sh2go erzeugt hat
# einliest und die Anzahl der Einträge liest, einmal inklusive
# Doubletten, einmal ohne Doubletten


# Hintergrund: 
#
# Das Tool <wc> (word count) liest eine Datei von der Festplatte oder
# über stdin ein und zählt alle Wörter. Mit der Option 'l' <wc -l> für 
# 'line' zählt es die Zeilen
#
MNF="mynumbers.txt"
cat ${MFN} | wc -l 
cat ${MFN} | sort | uniq | wc -l 


